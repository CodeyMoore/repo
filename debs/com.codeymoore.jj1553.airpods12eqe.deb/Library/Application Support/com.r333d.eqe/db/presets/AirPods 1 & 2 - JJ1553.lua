return {
    {
        name = "preamp",
        gain = -5.2855467796326,
    },
    {
        name = "eq",
        frequency = 31,
        Q = 1,
        gain = 2.361318,
    },
    {
        name = "eq",
        frequency = 60,
        Q = 0.836277,
        gain = 2.018856,
    },
    {
        name = "eq",
        frequency = 170,
        Q = 0.628881,
        gain = 2.322457,
    },
    {
        name = "eq",
        frequency = 310,
        Q = 1,
        gain = 3.795266,
    },
    {
        name = "eq",
        frequency = 600,
        Q = 1,
        gain = 4.056307,
    },
    {
        name = "eq",
        frequency = 1000,
        Q = 1,
        gain = 4.507793,
    },
    {
        name = "eq",
        frequency = 3000,
        Q = 1,
        gain = 2.258246,
    },
    {
        name = "eq",
        frequency = 6000,
        Q = 1,
        gain = 3.033174,
    },
    {
        name = "eq",
        frequency = 12000,
        Q = 2,
        gain = 3.894253,
    },
    {
        name = "eq",
        frequency = 14000,
        Q = 1.7342,
        gain = 2.571424,
    },
    {
        name = "eq",
        frequency = 16000,
        Q = 1.318457,
        gain = 5.057498,
    },
}